from flask import *
from flask_sqlalchemy import *
from sqlalchemy import *

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'oracle://mk:1@localhost:1521/xe'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
db = SQLAlchemy(app)


class user97(db.Model):
    __tablename__ = 'mk2'
    id =db.Column(db.Integer,db.Sequence('seq_book',start=1001),primary_key=True)
    Name = db.Column(db.String(80))
    Address = db.Column(db.String(120))
    Phone= db.Column(db.String(80))

@app.route("/")
def index():
    return render_template("register.html")
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        uname = request.form['uname']
        mail = request.form['mail']
        passw = request.form['passw']
        register = user97(Name= uname,Address= mail,Phone= passw)
        db.session.add(register)
        db.session.commit()
        return render_template("wel.html")


if __name__ == "__main__":
    db.create_all()
    app.run(debug=True)
