from flask import *
from flask_sqlalchemy import *
from sqlalchemy import *

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'oracle://mk:1@localhost:1521/xe'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
db = SQLAlchemy(app)


class user97(db.Model):
    __tablename__ = 'mk1'
    id =db.Column(db.Integer,db.Sequence('seq_book',start=1001),primary_key=True)
    f_n= db.Column(db.String(80))
    l_n = db.Column(db.String(120))
    title= db.Column(db.String(80))
    b= db.Column(db.String(80))

@app.route("/")
def index():
    return render_template("login.html")
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        a= request.form['f_name']
        b= request.form['l_name']
        c= request.form['hi']
        d=request.form['ti']
        register = user97(f_n=a,l_n=b,title=d,b=c)
        db.session.add(register)
        db.session.commit()
        return render_template("wel.html")
if __name__ == "__main__":
    db.create_all()
    app.run(debug=True)
